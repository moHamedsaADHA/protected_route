const express = require('express');
const courseRoutes = require('./routes/courseRoutes');
const connectDB = require('./config/db');
const dotenv = require('dotenv');

dotenv.config();
connectDB();

const app = express();
app.use(express.json());

app.use('/api/courses', courseRoutes);

app.get('/', (req, res) => {
  res.send('Welcome to Course Management API');
});

module.exports = app;